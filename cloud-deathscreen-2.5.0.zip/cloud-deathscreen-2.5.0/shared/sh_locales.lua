return {
	UI = {
		header = {
			title = "you are",
			subtitle = "unconscious",
			description = "You must decide whether to wait for help or confront the possibility of death. The choice is yours!",
		},
		buttons = {
			callEmergency = "call emergency",
			faceDeath = "face death",
		},
	},
	Notify = {
		PaidFine = "You paid $%s for your hospital bill.",
		NoMoney = "You don't have enough Money.",
	},
}
